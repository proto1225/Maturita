package com.example.simplewebbrowser;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText address;
    private WebView web;

    String error = "<html><body><h1>404</h1><h2>Page not found or no internet connection</h2><h3>Try:</h3><ul><li>Turning on WiFi/Data</li><li>Make sure the URL is correct</li></ul></body></html>";
    String about = "<html><body><h1>About</h1>Simple web browser, kinda sus can't even load reddit.<br>Made by Pavel Klepanec</body></html>";
    String aboutme = "<html><body><h1>About me</h1><h2>Pavel Klepanec</h2>19y/o has severe Path of Exile addiction<br>Glory to Ukraine.<br>...</body></html>";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e){
            e.printStackTrace();
        }
        setTheme(R.style.Theme_SimpleWebBrowser);
        setContentView(R.layout.activity_main);

        address = (EditText) findViewById(R.id.address);
        web =  (WebView) findViewById(R.id.web);

        web.setWebViewClient(new WebViewClient());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.about:    web.loadData(about, "text/html", "UTF-8");Toast.makeText(this, "About App", Toast.LENGTH_SHORT).show();break;
            case R.id.aboutme:  web.loadData(aboutme, "text/html", "UTF-8");Toast.makeText(this, "About Author", Toast.LENGTH_SHORT).show();break;
            case R.id.ende:     Toast.makeText(this, "exiting...", Toast.LENGTH_SHORT).show();finish();System.exit(0);break;
            default:            return super.onOptionsItemSelected(item);
        }return true;
    }

    public void back(View v){
        web.goBack();
    }

    public void forward(View v){
        web.goForward();
    }

    public void go(View v){
        String url = address.getText().toString();
        if(!url.contains("http")){
            url = "https://" + url;
        }
        web.loadUrl(url);

    web.setWebViewClient(new WebViewClient(){
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl){
            web.loadData(error, "text/html", "UTF-8");
        }
    });
    }
}