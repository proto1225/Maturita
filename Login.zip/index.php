<?php
session_start();
require_once 'Database.php';

if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: Welcome.php");
    exit;
}

$username = $password = $confirm_password = "";
$username_err = $password_err = $confirm_password_err = "";

if($_SERVER["REQUEST_METHOD"] == "POST") {

    if(empty(trim($_POST["username"]))) {
        $username_err = "Please enter a username.";
    } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', trim($_POST["username"]))) {
        $username_err = "Username can only contain letters, numbers and underscores.";
    } else {
        $conn = Database::Connect();
        $sql = "SELECT * FROM users WHERE Name LIKE :username";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":username", $param_username);
        $param_username = trim($_POST["username"]);
        $stmt->execute();

        if ($stmt->rowCount() >= 1) {
            $username_err = "Username already taken.";
        } else {
            $username = trim($_POST["username"]);
        }
    }
    unset($stmt);

    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter a password.";
    } elseif(strlen(trim($_POST["password"])) < 6){
        $password_err = "Password must have at least 6 characters.";
    } else{
        $password = trim($_POST["password"]);
    }

    if(empty(trim($_POST["confirm_password"]))){
        $confirm_password_err = "Please confirm password.";
    } else{
        $confirm_password = trim($_POST["confirm_password"]);
        if(empty($password_err) && ($password != $confirm_password)){
            $confirm_password_err = "Password did not match.";
        }
    }

    if(empty($password_err) && empty($username_err) && empty($confirm_password_err)){
        $sql = "INSERT INTO users (ID, name, password) VALUES (default, :username, :password)";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":username", $param_username, PDO::PARAM_STR);
        $param_username = trim($_POST["username"]);
        $stmt->bindParam(":password", $param_password, PDO::PARAM_STR);
        $param_password = password_hash($password, PASSWORD_DEFAULT);
        $stmt->execute();
        header("location: Login.php");
    }
    unset($stmt);

}
unset($conn);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sign up</title>
</head>
<body>
<h1>Sign up</h1>
<div>
<p>Please fill this form to create an account.</p>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) ?>" method="post">
        Name: <input type="text" name="username" <?php echo(!empty($username_err)) ? 'is-invalid' : ''; ?> value="<?php echo $username; ?>">
        <span><?php echo $username_err; ?></span><br>
        Password: <input type="password" name="password" <?php echo(!empty($password_err)) ? 'is-invalid' : ''; ?> value="<?php echo $password; ?>">
        <span><?php echo $password_err; ?></span><br>
        Confirm password: <input type="password" name="confirm_password" <?php echo(!empty($confirm_password_err)) ? 'is-invalid' : ''; ?> value="<?php echo $confirm_password; ?>">
        <span><?php echo $confirm_password_err; ?></span><br>
        <input type="submit">
        <input type="reset">
    </form>
</div>
<p>Already have an account? <a href="Login.php">Login here</a>.</p>
</body>
</html>